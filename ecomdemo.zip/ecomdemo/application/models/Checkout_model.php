<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Checkout_model extends CI_Model {

	public function order()
	{
		$this->load->database();
		$odd = $this->db->insert('order', $data);

		if($odd>0 )
		{
			return true;

		}
		else
		{
			return false;
		}
		//printf($data)
		//$res = $this->db->insert('product')->result_array();
		//return $res;
	}
	

}
