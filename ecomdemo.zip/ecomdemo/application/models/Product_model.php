<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model {

	public function getproduct()
	{
		$res = $this->db->get('product')->result_array();
		return $res;
	}
	public function getprbyid($id='')
	{
		return $this->db->get_where('product',['id'=>$id])->row();
	}

}

/* End of file Product_model.php */
/* Location: ./application/models/Product_model.php */