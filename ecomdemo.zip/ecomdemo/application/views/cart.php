<?php include('header.php');?>
		<div class="container">
		<div class="row">
			<div class="col-sm-6 col-sm-offset-3" id="cart">
				
			</div>
		</div>
			<!-- Content here -->
		</div>
		<!-- Optional JavaScript -->
<?php include('footer.php');?>