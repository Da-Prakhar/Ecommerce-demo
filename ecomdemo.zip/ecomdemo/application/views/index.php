<?php include('header.php');?>
		<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
				<div class="carousel-inner">
					<div class="carousel-item active">
						<img class="d-block w-100" src="<?=base_url('assets/');?>3.jpg" alt="First slide">
					</div>
					<div class="carousel-item">
						<img class="d-block w-100" src="<?=base_url('assets/');?>3.jpg" alt="Second slide">
					</div>
					<div class="carousel-item">
						<img class="d-block w-100" src="<?=base_url('assets/');?>3.jpg" alt="Third slide">
					</div>
				</div>
			</div>
		<div class="container">
			<div class="row">
			<?php 
			foreach ($product as $pr) {
				?>
				<div class="col-sm-3">
					<div class="card" style="width: 18rem;">
					<img class="card-img-top" src="<?=base_url('assets/');?>3.jpg" alt="Card image cap">
					<div class="card-body">
						<h5 class="card-title"><?=$pr['name']?></h5>
						<p class="card-text">₹ <?=$pr['price']?></p>
						<p class="card-text">Price :-  <?=$pr['des']?></p>
						<a href="javascript:void(0)" data-id="<?=$pr['id']?>" class="btn btn-primary addtocart">Add To Cart</a>
					</div>
				</div>
				</div>
				
		
				<?php
			}
			?>
				</div>
			<!-- Content here -->
		</div>
<?php include('footer.php');?>