<?php include('header.php');?>
		<div class="container">

			<!-- Content here -->
		</div>
		<!-- Optional JavaScript -->
<?php include('footer.php');?>