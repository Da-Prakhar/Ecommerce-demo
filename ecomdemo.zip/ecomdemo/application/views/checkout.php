<?php include('header.php');?>
		<div class="container">
			<div class="row">
				<form method="post" action="checkout">
					<div class="form-group">
					    <label for="exampleInputEmail1">Name</label>
					    <input type="Name" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Name">
					    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
					  </div>
					  <div class="form-group">
					    <label for="exampleInputEmail1">Email address</label>
					    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email" placeholder="Enter email">
					    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
					  </div>
					  <div class="form-group">
					    <label for="exampleInputEmail1">Address</label>
					    <textarea class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="address" placeholder="Enter Address">
					 </textarea>
					    <div class="form-group">
					    <label for="exampleInputEmail1">Payment Method</label>
					    <input type="radio" name="radio" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email" placeholder="Enter email">
					    <small id="emailHelp" class="form-text text-muted">Cash On Delivery</small>
					  </div>
					  </div>
					  <div class="form-check">
					    <input type="checkbox" name="checkbox" class="form-check-input" id="exampleCheck1">
					    <label class="form-check-label" for="exampleCheck1">Check me out</label>
					  </div>
					  <button type="submit" class="btn btn-primary">Submit</button>
					</form>
			</div>
			<!-- Content here -->
		</div>
		<!-- Optional JavaScript -->
<?php include('footer.php');?>