<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Welcome extends CI_Controller {
	/**
	* Index Page for this controller.
	*
	* Maps to the following URL
			* 		http://example.com/index.php/welcome
		*	- or -
			* 		http://example.com/index.php/welcome/index
		*	- or -
	* Since this controller is set as the default controller in
	* config/routes.php, it's displayed at http://example.com/
	*
	* So any other public methods not prefixed with an underscore will
	* map to /index.php/welcome/<method_name>
	* @see https://codeigniter.com/user_guide/general/urls.html
	*/
	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->load->model('product_model','pm');
		$this->load->library('cart');
	}
	public function index()
	{
		$data['product'] = $this->pm->getproduct();
		$this->load->view('index',$data);
	}
	public function addtocart()
	{
		$id = $this->input->post('id');
		$data = $this->pm->getprbyid($id);
		
		$data = array(
		        'id'      => $data->id,
		        'qty'     => 1,
		        'price'   =>$data->price,
		        'name'    => $data->name,
		        'image'=> $data->img
		);

		$q = $this->cart->insert($data);
		if($q){
			echo  "item Added to cart";
		}else{
			echo  "somthing went wrong";
		}

	}
	public function updatecart($value='')
	{
		$data  =$this->input->post();

		$this->cart->update($data);
		redirect('cart','refresh');

	}
	public function cartdetail()
	{
		echo form_open('welcome/updatecart'); ?>
		<table cellpadding="6" class="table table-striped" cellspacing="1" style="width:100%" border="0">
			<tr>
				<th>QTY</th>
				<th>Item Description</th>
				<th style="text-align:right">Item Price</th>
				<th style="text-align:right">Sub-Total</th>
			</tr>
			<?php $i = 1; ?>
			<?php foreach ($this->cart->contents() as $items): ?>
			<?php echo form_hidden($i.'[rowid]', $items['rowid']); ?>
			<tr>
				<td><?php echo form_input(array('name' => $i.'[qty]', 'value' => $items['qty'], 'maxlength' => '3', 'size' => '5')); ?></td>
				<td>
					<?php echo $items['name']; ?>
					<?php if ($this->cart->has_options($items['rowid']) == TRUE): ?>
					<p>
						<?php foreach ($this->cart->product_options($items['rowid']) as $option_name => $option_value): ?>
						<strong><?php echo $option_name; ?>:</strong> <?php echo $option_value; ?><br />
						<?php endforeach; ?>
					</p>
					<?php endif; ?>
				</td>
				<td style="text-align:right">₹<?php echo $this->cart->format_number($items['price']); ?></td>
				<td style="text-align:right">₹<?php echo $this->cart->format_number($items['subtotal']); ?></td>
			</tr>
			<?php $i++; ?>
			<?php endforeach; ?>
			<tr>
				<td colspan="2"> </td>
				<td class="right"><strong>Total</strong></td>
				<td class="right">₹<?php echo $this->cart->format_number($this->cart->total()); ?></td>
			</tr>
		</table>
		<p><?php echo form_submit('', 'Update your Cart',['class'=>'btn btn-primary']); ?></p>
		<p><a href="checkout" class="btn btn-success">CheckOut</a></p><?php
		}
}