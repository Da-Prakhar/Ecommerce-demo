<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Checkout extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->library('cart');
	}
	public function index()
	{
		$this->load->view('checkout');

		$data = $this->input->post();

		$name = $this->input->post("name");
		$email = $this->input->post("email");
		$address = $this->input->post("address");
		$radio = $this->input->post("radio");
		$check = $this->input->post("check");

	// 	$this->load->model('Checkout_model');
	// 	if($this->Checkout_model->order($data))
	// 	{
	// 		echo "Order has been Conformed";
	// 	}
	// 	else
	// 	{

	// 		echo "Something went Wrong";

	// 	}
	// //		print_r($data);
	}
	public function addorder($value='')
	{
		$itemsids = array();
		foreach ($this->cart->contents() as $items){
			$itemsids[]  = $items['id'];
		}
		  $pdi = implode(',',$itemsids);
	}
}

/* End of file Checkout.php */
/* Location: ./application/controllers/Checkout.php */